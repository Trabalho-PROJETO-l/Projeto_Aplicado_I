# Faculdade Mackenzie

Trabalhos de **Washington Venancio Jr** (RA 10780580), curso Tecnologia em Ciência de Dados, Universidade Presbiteriana Mackenzie.

| Pasta | Componente | Conteúdo |
|---|---|---|
| [`Projeto-Aplicado-I/`](Projeto-Aplicado-I/) | Projeto Aplicado I (Grupo 19) | Proposta analítica e análise exploratória em Python: OceanPact × ODS 13 |
