# Faculdade Mackenzie

Trabalhos de **Washington Venancio Jr** (RA 10780580), curso Tecnologia em Ciência de Dados, Universidade Presbiteriana Mackenzie.

| Pasta | Componente | Conteúdo |
|---|---|---|
| [`Projeto-Aplicado-I/`](Projeto-Aplicado-I/) | Projeto Aplicado I (Grupo 19) | OceanPact × ODS 13: proposta analítica, AED em Python e data storytelling (Etapas 1–3) |
