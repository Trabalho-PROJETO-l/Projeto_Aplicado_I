"""
Etapa 2 - Análise exploratória de dados (AED) - OceanPact x ODS 13.

Responde às perguntas da AED do roteiro de Projeto Aplicado I:
  1. número de exemplares e dimensões      5. correlações
  2. tipos de dados                        6. valores ausentes / incorretos
  3. medidas de posição e dispersão        7. anomalias e outliers
  4. distribuição e frequência

Saídas: tabelas em reports/tabelas/ e gráficos em reports/figures/.
Uso:  python src/analise_exploratoria.py   (rode antes src/preparacao_dados.py)
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
PROC = BASE / "data" / "processed"
FIG = BASE / "reports" / "figures"
TAB = BASE / "reports" / "tabelas"

# Paleta categórica validada (azul, laranja, verde-água) + tintas de texto
C1, C2, C3 = "#2a78d6", "#eb6834", "#1baf7a"
TXT, TXT2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 10, "axes.edgecolor": GRID,
    "axes.labelcolor": TXT2, "xtick.color": TXT2, "ytick.color": TXT2,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
    "grid.color": GRID, "grid.linewidth": 0.8, "axes.axisbelow": True,
    "axes.titleweight": "bold", "axes.titlesize": 12, "axes.titlecolor": TXT,
    "axes.titlelocation": "left", "legend.frameon": False,
})


def fmt(x, nd=2):
    return f"{x:,.{nd}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def salvar(fig, nome):
    fig.savefig(FIG / nome, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def estatisticas(df, cols):
    """Medidas de posição e dispersão, incluindo coeficiente de variação."""
    d = df[cols]
    out = pd.DataFrame({
        "n": d.count(), "media": d.mean(), "mediana": d.median(),
        "minimo": d.min(), "q1": d.quantile(.25), "q3": d.quantile(.75),
        "maximo": d.max(), "amplitude": d.max() - d.min(),
        "variancia": d.var(), "desvio_padrao": d.std(),
    })
    out["cv_pct"] = out["desvio_padrao"] / out["media"] * 100
    return out


def main():
    FIG.mkdir(parents=True, exist_ok=True)
    TAB.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(PROC / "oceanpact_anual.csv")
    asg = pd.read_csv(PROC / "indicadores_asg_long.csv")
    uni = pd.read_csv(PROC / "emissoes_por_unidade.csv")

    # 1-2. Dimensões e tipos ------------------------------------------------
    print("== 1. Dimensões ==")
    for nome, t in (("oceanpact_anual", df), ("indicadores_asg_long", asg), ("emissoes_por_unidade", uni)):
        print(f"{nome}: {t.shape[0]} linhas x {t.shape[1]} colunas")
    print("\n== 2. Tipos de dados (base anual) ==")
    print(df.dtypes.value_counts().to_string())
    df.dtypes.astype(str).rename("tipo").to_csv(TAB / "tipos_dados.csv")

    # 6. Valores ausentes -----------------------------------------------------
    aus = df.isna().sum().to_frame("ausentes")
    aus["pct"] = aus["ausentes"] / len(df) * 100
    aus = aus[aus["ausentes"] > 0].sort_values("ausentes", ascending=False)
    aus.round(1).to_csv(TAB / "valores_ausentes.csv")
    print("\n== 6. Valores ausentes (colunas com falta) ==")
    print(aus.round(1).to_string())

    fig, ax = plt.subplots(figsize=(9, 3.2))
    cols_m = ["receita_liquida_mi", "ebitda_ajustado_mi", "colaboradores", "escopo1_tco2e",
              "escopo3_tco2e", "intensidade_reportada_tco2e_por_mi", "energia_total_gj",
              "energia_renovavel_gj"]
    m = df.set_index("ano")[cols_m].notna().T
    ax.imshow(m.values, cmap=matplotlib.colors.ListedColormap(["#f3d3c6", "#cfe0f5"]), aspect="auto")
    ax.set_xticks(range(len(m.columns)), m.columns)
    ax.set_yticks(range(len(m.index)), m.index)
    ax.grid(False)
    for i in range(m.shape[0]):
        for j in range(m.shape[1]):
            ax.text(j, i, "ok" if m.values[i, j] else "ausente", ha="center", va="center",
                    fontsize=8, color=TXT2)
    ax.set_title("Mapa de completude da base anual (2021–2025)")
    salvar(fig, "01_mapa_ausentes.png")

    # 3. Posição e dispersão --------------------------------------------------
    cols = ["receita_liquida_mi", "escopo1_tco2e", "escopo2_tco2e", "escopo3_tco2e",
            "emissoes_total_tco2e", "intensidade_calc_total", "energia_total_gj"]
    est = estatisticas(df, cols)
    est.round(2).to_csv(TAB / "estatisticas_descritivas.csv")
    print("\n== 3. Medidas de posição e dispersão ==")
    print(est.round(2).T.to_string())

    # 4. Distribuição: participação por escopo e por unidade --------------------
    e = df.dropna(subset=["escopo1_tco2e"]).set_index("ano")
    fig, ax = plt.subplots(figsize=(8, 4))
    x = np.arange(len(e))
    w = 0.26
    for k, (c, cor, rot) in enumerate((("escopo1_tco2e", C1, "Escopo 1 (combustão própria)"),
                                        ("escopo2_tco2e", C2, "Escopo 2 (eletricidade)"),
                                        ("escopo3_tco2e", C3, "Escopo 3 (cadeia de valor)"))):
        b = ax.bar(x + (k - 1) * w, e[c] / 1000, w - 0.02, color=cor, label=rot)
        for r in b:
            ax.text(r.get_x() + r.get_width() / 2, r.get_height() + 3, fmt(r.get_height(), 1),
                    ha="center", fontsize=8, color=TXT2)
    ax.set_xticks(x, e.index)
    ax.set_ylabel("mil tCO₂e")
    ax.set_title("Emissões de GEE por escopo")
    ax.legend(loc="upper left")
    salvar(fig, "02_emissoes_por_escopo.png")

    part = e[["part_escopo1_pct", "part_escopo2_pct", "part_escopo3_pct"]].round(2)
    part.to_csv(TAB / "participacao_escopos.csv")
    print("\n== 4. Participação de cada escopo no total (%) ==")
    print(part.to_string())

    piv = uni.pivot_table(index=["ano", "escopo"], columns="unidade", values="tco2e")
    piv["pct_embarcacoes"] = piv["Embarcações"] / piv.sum(axis=1) * 100
    piv.round(2).to_csv(TAB / "emissoes_por_unidade.csv")
    print("\n== 4b. Emissões por unidade operacional ==")
    print(piv.round(2).to_string())

    # 5. Receita x emissões (índice base 2023 = 100; um único eixo) -------------
    base = e.loc[2023]
    idx = pd.DataFrame({
        "Receita líquida": e["receita_liquida_mi"] / base["receita_liquida_mi"] * 100,
        "Escopo 1": e["escopo1_tco2e"] / base["escopo1_tco2e"] * 100,
        "Emissões totais (1+2+3)": e["emissoes_total_tco2e"] / base["emissoes_total_tco2e"] * 100,
    })
    fig, ax = plt.subplots(figsize=(8, 4))
    for (nome, s), cor in zip(idx.items(), (C1, C2, C3)):
        ax.plot(s.index, s.values, color=cor, lw=2, marker="o", ms=7, label=nome)
        ax.annotate(fmt(s.iloc[-1], 0), (s.index[-1], s.iloc[-1]), xytext=(8, 0),
                    textcoords="offset points", va="center", fontsize=9, color=TXT2)
    ax.axhline(100, color=TXT2, lw=0.8, ls=":")
    ax.set_xticks(idx.index)
    ax.set_ylabel("índice (2023 = 100)")
    ax.set_title("Desde 2023: receita +29%, emissões totais +37%, Escopo 1 +3%")
    ax.legend(loc="upper left")
    salvar(fig, "03_indice_receita_emissoes.png")
    idx.round(1).to_csv(TAB / "indice_base2023.csv")

    # Intensidade: calculada x reportada
    fig, ax = plt.subplots(figsize=(8, 4))
    w = 0.38
    ax.bar(x - w / 2, e["intensidade_calc_total"], w - 0.02, color=C1, label="Calculada (total ÷ receita líquida)")
    ax.bar(x + w / 2, e["intensidade_reportada_tco2e_por_mi"].fillna(0), w - 0.02, color=C2,
           label="Reportada pela empresa")
    for i, (a, r) in enumerate(zip(e["intensidade_calc_total"], e["intensidade_reportada_tco2e_por_mi"])):
        ax.text(i - w / 2, a + 2, fmt(a, 1), ha="center", fontsize=8, color=TXT2)
        ax.text(i + w / 2, (0 if np.isnan(r) else r) + 2, "n/d" if np.isnan(r) else fmt(r, 1),
                ha="center", fontsize=8, color=TXT2)
    ax.set_xticks(x, e.index)
    ax.set_ylabel("tCO₂e por R$ milhão")
    ax.set_title("Intensidade de emissões: calculada × reportada")
    ax.set_ylim(0, 175)
    ax.legend(loc="upper left", ncol=2)
    salvar(fig, "04_intensidade_calc_vs_reportada.png")

    # Correlações (Pearson e Spearman) ----------------------------------------
    cc = ["receita_liquida_mi", "escopo1_tco2e", "escopo3_tco2e", "emissoes_total_tco2e",
          "energia_total_gj", "colaboradores", "taxa_ocupacao_frota_pct"]
    rot = ["Receita", "Escopo 1", "Escopo 3", "Emissões totais", "Energia", "Colaboradores", "Ocupação frota"]
    pear = e[cc].corr(method="pearson")
    spear = e[cc].corr(method="spearman")
    pear.round(3).to_csv(TAB / "correlacao_pearson.csv")
    spear.round(3).to_csv(TAB / "correlacao_spearman.csv")
    print("\n== 5. Correlação de Pearson (n = 3 anos: apenas indicativa) ==")
    print(pear.round(2).to_string())
    fig, ax = plt.subplots(figsize=(7, 5.6))
    im = ax.imshow(pear.values, cmap="RdBu_r", vmin=-1, vmax=1)
    ax.set_xticks(range(len(rot)), rot, rotation=40, ha="right")
    ax.set_yticks(range(len(rot)), rot)
    ax.grid(False)
    for i in range(len(rot)):
        for j in range(len(rot)):
            v = pear.values[i, j]
            ax.text(j, i, fmt(v, 2), ha="center", va="center", fontsize=8,
                    color="white" if abs(v) > .6 else TXT)
    fig.colorbar(im, ax=ax, shrink=.8, label="r de Pearson")
    ax.set_title("Matriz de correlação (2023–2025, n = 3)")
    salvar(fig, "05_matriz_correlacao.png")

    # Dispersão: ocupação da frota x Escopo 1 (fator operacional)
    fig, ax = plt.subplots(figsize=(6.5, 4))
    ax.scatter(e["taxa_ocupacao_frota_pct"], e["escopo1_tco2e"] / 1000, s=80, color=C1,
               edgecolor="white", linewidth=2, zorder=3)
    for a, xo, yo in zip(e.index, e["taxa_ocupacao_frota_pct"], e["escopo1_tco2e"] / 1000):
        ax.annotate(str(a), (xo, yo), xytext=(8, 4), textcoords="offset points", fontsize=9, color=TXT2)
    ax.set_xlabel("taxa de ocupação da frota (%)")
    ax.set_ylabel("Escopo 1 (mil tCO₂e)")
    ax.set_title("Ocupação da frota × emissões diretas")
    salvar(fig, "06_ocupacao_vs_escopo1.png")

    # Tendência dos indicadores ASG (2022–2024) ----------------------------------
    sel = ["NOx", "Resíduos gerados - total", "Resíduos perigosos", "TRIR"]
    t = asg[asg["indicador"].isin(sel)].pivot_table(index="ano", columns="indicador", values="valor")
    fig, axs = plt.subplots(1, 4, figsize=(12, 3), sharex=True)
    for ax, c in zip(axs, sel):
        ax.plot(t.index, t[c], color=C1, lw=2, marker="o", ms=6)
        ax.set_title(c, fontsize=10)
        ax.set_xticks(t.index)
        for a, v in t[c].items():
            ax.annotate(fmt(v, 2 if c == "TRIR" else 0), (a, v), xytext=(0, 7),
                        textcoords="offset points", ha="center", fontsize=8, color=TXT2)
        ax.margins(y=.25)
    fig.suptitle("Outros indicadores ASG (2022–2024)", x=0.01, ha="left", fontweight="bold", color=TXT)
    fig.tight_layout()
    salvar(fig, "07_indicadores_asg.png")

    # 7. Anomalias e outliers --------------------------------------------------
    print("\n== 7. Anomalias ==")
    var = df.set_index("ano")[["var_receita_liquida_mi_pct", "var_escopo1_tco2e_pct",
                                "var_escopo3_tco2e_pct", "var_emissoes_total_tco2e_pct"]]
    var.round(2).to_csv(TAB / "variacoes_anuais.csv")
    print(var.round(1).dropna(how="all").to_string())
    # Outliers por IQR dentro de cada indicador da base longa (por indicador, 2022-2024)
    linhas = []
    for ind, g in asg.dropna(subset=["valor"]).groupby("indicador"):
        if len(g) < 3:
            continue
        mv = g["valor"]
        z = (mv - mv.mean()) / mv.std()
        g = g.assign(z=z)
        linhas.append(g.loc[z.abs() == z.abs().max(), ["indicador", "ano", "valor", "z"]])
    extremos = pd.concat(linhas).sort_values("z", key=abs, ascending=False)
    extremos.round(3).to_csv(TAB / "valores_extremos_por_indicador.csv", index=False)
    print("\nAno mais distante da média em cada indicador (z-score):")
    print(extremos.head(8).round(2).to_string(index=False))
    print("\nObservação: com 3 anos por indicador, |z| máximo possível é 1,15; "
          "anomalias são avaliadas por variação anual e por quebra metodológica.")


if __name__ == "__main__":
    main()
