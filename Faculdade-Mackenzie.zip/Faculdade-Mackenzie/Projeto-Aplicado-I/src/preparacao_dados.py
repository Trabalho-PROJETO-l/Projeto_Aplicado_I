"""
Etapa 1 - Carga, limpeza e integração dos dados da OceanPact.

Lê os arquivos brutos em data/raw, padroniza tipos, calcula variáveis derivadas
(emissões totais, intensidade calculada, participação por escopo) e grava a base
integrada em data/processed/oceanpact_anual.csv.

Uso:  python src/preparacao_dados.py
"""
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
RAW = BASE / "data" / "raw"
PROC = BASE / "data" / "processed"


def carregar_brutos():
    fin = pd.read_csv(RAW / "financeiro_anual.csv")
    emi = pd.read_csv(RAW / "emissoes_anual.csv")
    uni = pd.read_csv(RAW / "emissoes_por_unidade.csv")
    asg = pd.read_csv(RAW / "indicadores_asg_long.csv")
    return fin, emi, uni, asg


def integrar(fin: pd.DataFrame, emi: pd.DataFrame) -> pd.DataFrame:
    """Junta financeiro e emissões por ano e cria as variáveis derivadas."""
    df = fin.drop(columns="fonte").merge(
        emi.drop(columns="fonte"), on="ano", how="left"
    )
    df["emissoes_total_tco2e"] = df[["escopo1_tco2e", "escopo2_tco2e", "escopo3_tco2e"]].sum(
        axis=1, min_count=3
    )
    df["emissoes_escopo12_tco2e"] = df[["escopo1_tco2e", "escopo2_tco2e"]].sum(axis=1, min_count=2)
    # Intensidade recalculada com a receita líquida (tCO2e por R$ milhão)
    df["intensidade_calc_total"] = df["emissoes_total_tco2e"] / df["receita_liquida_mi"]
    df["intensidade_calc_escopo12"] = df["emissoes_escopo12_tco2e"] / df["receita_liquida_mi"]
    df["dif_intensidade_pct"] = (
        (df["intensidade_reportada_tco2e_por_mi"] - df["intensidade_calc_total"])
        / df["intensidade_calc_total"] * 100
    )
    for e in ("escopo1", "escopo2", "escopo3"):
        df[f"part_{e}_pct"] = df[f"{e}_tco2e"] / df["emissoes_total_tco2e"] * 100
    df["margem_ebitda_pct"] = df["ebitda_ajustado_mi"] / df["receita_liquida_mi"] * 100
    df["emissoes_por_colaborador"] = df["emissoes_total_tco2e"] / df["colaboradores"]
    df["energia_por_receita_gj_mi"] = df["energia_total_gj"] / df["receita_liquida_mi"]
    # variações ano a ano (%)
    for c in ("receita_liquida_mi", "escopo1_tco2e", "escopo3_tco2e", "emissoes_total_tco2e"):
        df[f"var_{c}_pct"] = df[c].pct_change(fill_method=None) * 100
    return df


def main():
    PROC.mkdir(parents=True, exist_ok=True)
    fin, emi, uni, asg = carregar_brutos()
    df = integrar(fin, emi)
    df.round(4).to_csv(PROC / "oceanpact_anual.csv", index=False)
    asg["valor"] = pd.to_numeric(asg["valor"], errors="coerce")
    asg.to_csv(PROC / "indicadores_asg_long.csv", index=False)
    uni.to_csv(PROC / "emissoes_por_unidade.csv", index=False)
    print(f"Base integrada: {df.shape[0]} linhas x {df.shape[1]} colunas -> {PROC/'oceanpact_anual.csv'}")


if __name__ == "__main__":
    main()
