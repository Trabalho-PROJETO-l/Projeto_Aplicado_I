# Projeto Aplicado I: Análise da Correlação entre Faturamento e Emissões de GEE na OceanPact (ODS 13)

**Universidade Presbiteriana Mackenzie, Tecnologia em Ciência de Dados, Grupo 19**
Prof. Fabio Lopes · 2º semestre de 2026

| RA | Integrante |
|---|---|
| 10782175 | Allan Rafael Basilio |
| 10219078 | William Oshiro Correa |
| 10780580 | Washington Venancio Junior |
| 10420649 | Pedro Mantovanni Junior |

## Objetivo
Verificar se o crescimento financeiro da OceanPact (receita líquida) está acompanhado de redução da **intensidade** de emissões de Gases de Efeito Estufa (tCO₂e por R$ milhão de receita). A pergunta se relaciona ao ODS 13 (Ação contra a mudança global do clima) da Agenda 2030.

## Entregas
| Etapa | Conteúdo | Arquivo |
|---|---|---|
| 1 | Definição do projeto, cronograma e fontes | `docs/Etapa1_Projeto_OceanPact_Grupo19.pdf` |
| 2 | Proposta analítica, metadados e análise exploratória | `docs/Etapa2_Proposta_Analitica_AED_Grupo19.pdf` |
| 3 | Esboço do data storytelling, AED ampliada (perfil por variável) e notebook revisado | `docs/Etapa3_Storytelling_AED_Grupo19.pdf` |

## Estrutura do repositório
```
Projeto-Aplicado-I/
├── data/
│   ├── raw/                 # dados coletados das fontes públicas (CSV)
│   └── processed/           # base integrada e limpa (gerada pelos scripts)
├── src/
│   ├── preparacao_dados.py  # carga, limpeza, integração e variáveis derivadas
│   └── analise_exploratoria.py  # estatística descritiva, correlações, ausentes, anomalias
├── notebooks/aed_oceanpact.ipynb   # AED passo a passo, comentada e já executada
├── reports/
│   ├── figures/             # gráficos gerados (PNG)
│   ├── tabelas/             # tabelas de resultados (CSV)
│   └── saida_aed.txt        # saída completa do script de AED
├── docs/                    # PDFs entregues e dicionário de dados
└── requirements.txt
```

## Como executar
```bash
pip install -r requirements.txt
python src/preparacao_dados.py
python src/analise_exploratoria.py
# ou: jupyter notebook notebooks/aed_oceanpact.ipynb
```

## Principais achados da AED
1. **Escopo 3 domina o inventário.** A cadeia de valor responde por 71% a 81% das emissões totais. O Escopo 2 (eletricidade) fica em cerca de 0,03%. No Escopo 1, as embarcações geram 99,4% das emissões.
2. **Crescimento financeiro × emissões diretas (2023→2025).** A receita cresceu 29,4% e o Escopo 1 cresceu 3,2%. Com isso, a intensidade de Escopos 1+2 caiu 20,2%, de 33,0 para 26,4 tCO₂e por R$ milhão. Já as emissões totais cresceram 36,9%, acima da receita.
3. **Quebra metodológica em 2024.** O Escopo 3 subiu 46,9% quando a empresa incluiu a categoria "ativos arrendados". Por isso, 2023 e 2024 não são diretamente comparáveis no Escopo 3.
4. **Inconsistência na intensidade reportada.** Para 2023, a intensidade recalculada (114,1) bate com a reportada (114,03). Para 2024, a recalculada dá 141,5, contra 105,9 reportada (diferença de 25%), o que indica um denominador diferente da receita líquida. A intensidade de 2025 ainda não tem fonte primária publicada.
5. **Fator operacional.** O Escopo 1 acompanha a ocupação da frota (r = 0,66). Em 2024 houve mais tempo de embarcações em docagem, o que deu menor ocupação (79%) e menores emissões diretas.
6. **Limitações.** As emissões só estão disponíveis para 2023–2025 (n = 3), então as correlações são apenas indicativas. Para 2021 e 2022 há só dados financeiros.

## Etapa 3: data storytelling
**Mensagem central:** por real faturado, a frota da OceanPact emite 20% menos (intensidade de Escopos 1+2 de 33,0 para 26,4 tCO₂e por R$ milhão), mas a pegada total ainda cresce com o negócio (+5,8% na intensidade total), e os dados públicos não bastam para provar a descarbonização.

![Gráfico-síntese](reports/figures/09_storytelling_intensidade.png)

O que mudou na AED:
- `reports/tabelas/perfil_variaveis.csv`: perfil de cada coluna, com n, ausentes, mínimo, quartis, mediana, média, máximo, amplitude, IQR, variância, desvio-padrão, CV, assimetria, z máximo e outliers pela regra do IQR;
- `reports/tabelas/perfil_indicadores_asg.csv`: o mesmo perfil para os 25 indicadores ASG;
- `reports/tabelas/frequencia_categorias_asg.csv`: frequência das categorias;
- novas figuras: `08_distribuicao_variaveis.png` (boxplot com os anos observados), `09_storytelling_intensidade.png` (gráfico-síntese) e `10_frequencias_categoricas.png`;
- o notebook foi reescrito e segue o roteiro da AED, com o código e os comentários em cada etapa.

Resultado da verificação de outliers: nenhuma coluna tem outlier pela regra do IQR, e o |z| máximo é 1,15. As anomalias relevantes são metodológicas: a mudança no Escopo 3 em 2024 e a intensidade reportada que não se reproduz.

## Fontes
- OceanPact. *Painel de Indicadores ASG 2024* (dados 2022–2024): https://oceanpact.com/wp-content/uploads/2026/05/Indicator-dashboard-2024.pdf
- OceanPact. *Relatório Anual de Sustentabilidade 2023*: https://oceanpact.com/wp-content/uploads/2024/05/OP_relatorio_sustentabilidade_2023_bx.pdf
- OceanPact RI. *Release de Resultados 4T24* e *4T25*: https://api.mziq.com/mzfilemanager/v2/d/d3d19aad-2471-4309-a7e5-a5dbc02c0a1c/59ffa746-80ec-d9ed-6231-4f87eb10c845?origin=2
- Portos e Navios (22/06/2026). *Relatório de sustentabilidade 2025 da OceanPact aponta alta de 6% nas emissões*: https://www.portosenavios.com.br/noticias/offshore/relatorio-de-sustentabilidade-2025-da-oceanpact-aponta-alta-de-6-nas-emissoes-e-avanco-em-descarbonizacao
- Knaflic, C. N. *Storytelling com dados*. Alta Books, 2019 (referência para a Etapa 3).
- Stock Analysis. *OceanPact (OPCT3) revenue* (receita 2021–2022): https://stockanalysis.com/quote/bvmf/OPCT3/revenue/
