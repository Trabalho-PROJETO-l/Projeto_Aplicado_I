# Dicionário de dados e metadados

| Item | Descrição |
|---|---|
| Tipo de arquivo | CSV (UTF-8, separador vírgula, decimal ponto) |
| Origem | Dados **abertos**: relatórios públicos de sustentabilidade e de Relações com Investidores da OceanPact (B3: OPCT3) |
| Sensibilidade | Não há dados pessoais. Os indicadores são agregados por ano e por unidade operacional |
| Validade | 2021–2025. Atualização anual (relatório de sustentabilidade) e trimestral (releases). Fica obsoleto quando sair o relatório de 2026 |
| Proprietário | OceanPact Serviços Marítimos S.A. A coleta e estruturação foram feitas pelo Grupo 19 |
| Restrições de uso | Uso acadêmico com citação da fonte. Sem restrição de LGPD, pois não há dados pessoais |
| Informações adicionais | Emissões em tCO₂e (GHG Protocol). Escopo 2 pela abordagem de escolha de compra (market-based). Valores financeiros em R$ milhões nominais |

## data/raw/financeiro_anual.csv (5 linhas × 10 colunas)
| Atributo | Tipo | Definição |
|---|---|---|
| ano | inteiro | Ano-calendário |
| receita_liquida_mi | real | Receita líquida consolidada (R$ milhões) |
| receita_embarcacoes_mi | real | Receita do segmento Embarcações (R$ milhões) |
| receita_servicos_mi | real | Receita do segmento Serviços (R$ milhões) |
| ebitda_ajustado_mi | real | EBITDA ajustado (R$ milhões) |
| lucro_liquido_mi | real | Lucro (prejuízo) líquido (R$ milhões) |
| taxa_ocupacao_frota_pct | real | Taxa média anual de ocupação da frota (%) |
| frota_embarcacoes | inteiro | Número de embarcações da frota |
| colaboradores | inteiro | Número de colaboradores no fim do ano |
| fonte | texto | Documento de origem |

## data/raw/emissoes_anual.csv (3 linhas × 10 colunas)
| Atributo | Tipo | Definição |
|---|---|---|
| escopo1_tco2e | real | Emissões diretas (combustão em embarcações, bases e escritórios) |
| escopo2_tco2e | real | Emissões indiretas de energia elétrica comprada |
| escopo3_tco2e | real | Outras emissões indiretas da cadeia de valor |
| intensidade_reportada_tco2e_por_mi | real | Intensidade publicada pela empresa (tCO₂e por R$ milhão) |
| energia_total_gj, energia_renovavel_gj, energia_nao_renovavel_gj | real | Consumo de energia dentro da organização (GJ) |
| diesel_puro_l | real | Consumo de diesel puro (L) |

## data/raw/emissoes_por_unidade.csv (12 linhas × 4 colunas)
Formato longo: `ano`, `escopo` (Escopo 1/2), `unidade` (Bases, Embarcações, Escritórios), `tco2e`.

## data/raw/indicadores_asg_long.csv (75 linhas × 6 colunas)
Formato longo: `ano` (2022–2024), `categoria` (Resíduos, Emissões atmosféricas, Água, Segurança, Energia), `indicador`, `valor`, `unidade`, `fonte`.

## Variáveis derivadas (data/processed/oceanpact_anual.csv)
| Atributo | Fórmula |
|---|---|
| emissoes_total_tco2e | Escopo 1 + Escopo 2 + Escopo 3 |
| intensidade_calc_total | emissões totais ÷ receita líquida |
| intensidade_calc_escopo12 | (Escopo 1 + Escopo 2) ÷ receita líquida |
| dif_intensidade_pct | (reportada − calculada) ÷ calculada × 100 |
| part_escopoX_pct | participação de cada escopo no total (%) |
| margem_ebitda_pct | EBITDA ajustado ÷ receita líquida × 100 |
| var_*_pct | variação percentual em relação ao ano anterior |
